﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EvilDicom.Image;
using EvilDicom.VR;

namespace EvilDicom.Helper
{
    public class CompressionHelper
    {
        public static void Decompress(PixelData data, ImageProperties properties, ref float[] values)
        {
            //TODO: Add code to decompress fragments
        }
    }
}


//Copyright © 2012 Rex Cardan, Ph.D


