﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EvilDicom.Image
{
    public struct PixelCell
    {
        public byte[] Bytes { get; set; }
        public int BitsStored { get; set; }
       
    }
}


//Copyright © 2012 Rex Cardan, Ph.D


