﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EvilDicom
{
    namespace VR
    {
        public class PersonsName : AbstractStringVR
        {
            public PersonsName() { base.VR = "PN"; }
        }
      
    }

}


//Copyright © 2012 Rex Cardan, Ph.D


