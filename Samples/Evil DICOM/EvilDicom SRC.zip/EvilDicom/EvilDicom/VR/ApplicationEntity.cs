﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EvilDicom
{
    namespace VR
    {
        public class ApplicationEntity : AbstractStringVR
        {
            public ApplicationEntity() { base.VR = "AE"; }
        }
    }

}


//Copyright © 2012 Rex Cardan, Ph.D


